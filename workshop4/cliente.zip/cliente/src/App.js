import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Home from './components/Pages/Home';
import Teachers from './components/Pages/Teachers';
import Courses from './components/Pages/Courses';
import Login from './components/Pages/Login';
import Layout from './components/Layout/Layaout';

const App = () => {
  const [isLoggedIn, setLoggedIn] = useState(false);

  useEffect(() => {
    const token = sessionStorage.getItem('token');
    if (token) {
      setLoggedIn(true);
    }
  }, []);

  const handleLogin = () => {
    setLoggedIn(true);
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    setLoggedIn(false);
  };

  return (
    <Router>
      <Routes>
        <Route
           path="/"
            element={<Navigate to="/login" replace />}
        />
        <Route
          path="/login"
          element={
            isLoggedIn ? (
              <Navigate to="/" replace />
            ) : (
              <Login handleLogin={handleLogin} setLoggedIn={setLoggedIn} />
            )
          }
        />
        <Route
          path="/home"
          element={
            isLoggedIn ? (
              <Layout isLoggedIn={isLoggedIn} handleLogout={handleLogout}>
                <Home />
              </Layout>
            ) : (
              <Navigate to="/login" replace />
            )
          }
        />
        <Route
          path="/teachers"
          element={
            isLoggedIn ? (
              <Layout isLoggedIn={isLoggedIn} handleLogout={handleLogout}>
                <Teachers />
              </Layout>
            ) : (
              <Navigate to="/login" replace />
            )
          }
        />
        <Route
          path="/courses"
          element={
            isLoggedIn ? (
              <Layout isLoggedIn={isLoggedIn} handleLogout={handleLogout}>
                <Courses />
              </Layout>
            ) : (
              <Navigate to="/login" replace />
            )
          }
        />
      </Routes>
    </Router>
  );
};

export default App;
