import React, { useState, useEffect } from "react";
import '../../styles/home.css'; // Importa los estilos CSS

const Courses = () => {
    const [courses, setCourses] = useState([]);

    useEffect(() => {
        const getCourses = async () => {
            const token = localStorage.getItem("token");
            try {
                const response = await fetch("http://localhost:4000/graphql", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${token}`,
                    },
                    body: JSON.stringify({
                        query: `
              query {
                courses {
                  id
                  name
                  credits
                  teacher {
                    id
                    first_name
                    last_name
                    cedula
                    age
                  }
                }
              }
            `,
                    }),
                });
                const data = await response.json();
                if (response.ok) {
                    setCourses(data.data.courses);
                } else {
                    console.error(
                        "Error al obtener datos de cursos:",
                        data.errors
                    );
                }
            } catch (error) {
                console.error("Error al obtener datos de cursos:", error);
            }
        };

        getCourses();
    }, []);



    return (
      <div className="course-container">
        <h2 className="course-title">Lista de Cursos</h2>
        <ul className="course-list">
          {courses.map((course) => (
            <li key={course.id} className="course-item">
              <strong>{course.name}</strong> - {course.credits} créditos
              <br />
              Profesor: {course.teacher.first_name} {course.teacher.last_name}
              <br />
              Cédula: {course.teacher.cedula}
              <br />
              Edad: {course.teacher.age} años
            </li>
          ))}
        </ul>
      </div>
    );
  };

export default Courses;
