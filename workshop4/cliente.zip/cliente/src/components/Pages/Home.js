import React, { useEffect, useState } from 'react';
import { jwtDecode } from "jwt-decode";
import '../../styles/home.css'; // Importa los estilos CSS
const Home = () => {
  const [userName, setUserName] = useState('');
  const [currentDate, setCurrentDate] = useState('');

  useEffect(() => {
    // Obtener el token del almacenamiento local
    const token = localStorage.getItem('token');
    
    // Decodificar el token para obtener información del usuario
    if (token) {
        const decodedToken = jwtDecode(token);  
        if (decodedToken && decodedToken.name) {
        setUserName(decodedToken.name);
      }
    }

    // Obtener la fecha actual
    const date = new Date();
    const formattedDate = `${date.getDate()}/${date.getMonth() + 1}/${date.getFullYear()}`;
    setCurrentDate(formattedDate);
  }, []);

  return (
    <div className="home-container">
      <h1 className="welcome-message">Bienvenido, {userName}.</h1>
      <p className="date-info">Hoy es {currentDate}.</p>
    </div>
  );
};

export default Home;
