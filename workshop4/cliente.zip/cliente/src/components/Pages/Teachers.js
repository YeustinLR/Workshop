import React, { useState, useEffect } from 'react';
import '../../styles/teachers.css'; // Importa los estilos CSS

const Teachers = () => {
  const [teachers, setTeachers] = useState([]);

  useEffect(() => {
    const getTeachers = async () => {
      const token = localStorage.getItem('token');
      try {
        const response = await fetch('http://localhost:4000/graphql', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({
            query: `
              query {
                teachers {
                  id
                  first_name
                  last_name
                  cedula
                  age
                }
              }
            `
          })
        });
        const data = await response.json();
        if (response.ok) {
          setTeachers(data.data.teachers);
        } else {
          console.error('Error al obtener datos de profesores:', data.errors);
        }
      } catch (error) {
        console.error('Error al obtener datos de profesores:', error);
      }
    };

    getTeachers();
  }, []);



  return (
    <div className="teacher-container">
      <h2 className="teacher-title">Lista de Profesores</h2>
      <ul className="teacher-list">
        {teachers.map((teacher) => (
          <li key={teacher.id} className="teacher-item">
            {teacher.first_name} {teacher.last_name} - {teacher.age} años
          </li>
        ))}
      </ul>
    </div>
  );
};
export default Teachers;
