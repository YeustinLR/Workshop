import React from 'react';
import { Link } from 'react-router-dom';
import '../../styles/navbar.css'; // Importa los estilos CSS

const Layout = ({ isLoggedIn, handleLogout, children }) => {
  return (
    <div>
      <nav className="navbar-container">
        <ul className="navbar-nav">
          {isLoggedIn ? (
            <>
              <li className="nav-item">
                <Link to="/home" className="nav-link">Home</Link>
              </li>
              <li className="nav-item">
                <Link to="/teachers" className="nav-link">Profesores</Link>
              </li>
              <li className="nav-item">
                <Link to="/courses" className="nav-link">Cursos</Link>
              </li>
              <li className="nav-item">
                <button onClick={handleLogout} className="logout-button">Cerrar Sesión</button>
              </li>
            </>
          ) : (
            <li className="nav-item">
              <Link to="/" className="nav-link">Inicio</Link>
            </li>
          )}
        </ul>
      </nav>
      <main>{children}</main>
    </div>
  );
};

export default Layout;
